<?php

class LoginRequiredMiddleware extends BaseMiddleware {
    public function apply(BaseController $controller, array $context)
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $currentUrl = $_SERVER['REQUEST_URI'];

        $isLoginPage = str_starts_with($currentUrl, '/login');
        $isStaticAsset = str_starts_with($currentUrl, '/public') || str_ends_with($currentUrl, '.css') || str_ends_with($currentUrl, '.js');

        if (!isset($_SESSION['is_logged']) || $_SESSION['is_logged'] !== true) {
            if (!$isLoginPage && !$isStaticAsset) {
                header("Location: /login");
                exit;
            }
        }
    }
}
