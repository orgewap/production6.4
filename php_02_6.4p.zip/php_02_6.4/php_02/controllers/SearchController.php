<?php
require_once "BaseTanksTwigController.php";

class SearchController extends BaseTanksTwigController {
    public $template = "search.twig";
    
    public function getContext(): array
    {
        $context = parent::getContext();

        $type = $_GET['type'] ?? '';
        $title = $_GET['title'] ?? '';
        $info = $_GET['info'] ?? '';

        if ($type == '') {
            $sql = <<<EOL
SELECT id, title
FROM tanks
WHERE (:title = '' OR title LIKE CONCAT('%', :title, '%'))
  AND (:info = '' OR info LIKE CONCAT('%', :info, '%'))
EOL;
            $query = $this->pdo->prepare($sql);
            $query->bindValue("title", $title);
            $query->bindValue("info", $info);
        } else {
            $sql = <<<EOL
SELECT id, title
FROM tanks
WHERE (:title = '' OR title LIKE CONCAT('%', :title, '%'))
  AND type = :type
  AND (:info = '' OR info LIKE CONCAT('%', :info, '%'))
EOL;
            $query = $this->pdo->prepare($sql);
            $query->bindValue("title", $title);
            $query->bindValue("type", $type);
            $query->bindValue("info", $info);
        }

        $query->execute(); 
        $context['title_objects'] = $query->fetchAll();

       
        $context['type'] = $type;
        $context['title'] = $title;
        $context['info'] = $info;

        return $context;
    }
}
