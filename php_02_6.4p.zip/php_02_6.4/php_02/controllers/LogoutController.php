<?php
require_once "BaseTanksTwigController.php";

class LogoutController extends BaseTanksTwigController {
    public $template = "login.twig"; // не используется

    public function get(array $context) {
        $_SESSION["is_logged"] = false;
        header("Location: /login");
        exit;
    }
}
