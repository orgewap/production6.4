<?php

class TanksRestController {
    public  PDO $pdo;
    public function __construct()
    {
        //echo 123;
        $this->pdo = new PDO("mysql:host=localhost;
        dbname=world_of_tanks;charset=utf8", "root", "");
    }
    public function process($id=null) {
        //if (ob_get_length()) ob_clean();
        $method = $_SERVER['REQUEST_METHOD'];
        //echo "id=$id, method=$method";
        $data = [];
        if($id) {
            if($method == "GET") {
                $data = $this->retrieve($id);
            } elseif ($method == "PUT") {
                $data = $this->update($id);
            } elseif ($method == "DELETE") {
                $data = $this->remove($id);
            }
        } else {
            if($method == "GET") {
                $data = $this->list();
            } elseif ($method == "POST") {
                $data = $this->create();
            }
        }
        header(('Content-type: application/json'));
        echo json_encode($data ?? []);
        exit;
    }
    public function list() {
        $query = $this->pdo->query("SELECT * FROM tanks");
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    public function create() {
        $json = file_get_contents('php://input');
        $data = json_decode($json, true, 512, JSON_THROW_ON_ERROR);

        $title = $data['title'] ?? '';
        $image = $data['image'] ?? '';
        $description = $data['description'] ?? '';
        $info = $data['info'] ?? '';
        $type = $data['type'] ?? '';

        $query = $this->pdo->prepare("
        INSERT INTO tanks(title, image, description, info, type)
        VALUES (:title, :image, :description, :info, :type)
        ");
        $query->bindValue("title", $title);
        $query->bindValue("image", $image);
        $query->bindValue("description", $description);
        $query->bindValue("info", $info);
        $query->bindValue("type", $type);

        $query->execute();
        $id = $this->pdo->lastInsertId();

        return [
            "id" => $id
        ];
    }

    public function retrieve($id) {
        $query = $this->pdo->prepare("SELECT * FROM tanks WHERE id = :my_id");
        $query->bindValue("my_id", $id);
        $query->execute();
        return $query->fetch(PDO::FETCH_ASSOC);
    }

    public function update($id) {
        $json = file_get_contents('php://input');
        $data = json_decode($json, true, 512, JSON_THROW_ON_ERROR);

        $query = $this->pdo->prepare("SELECT * FROM tanks WHERE id = :my_id");
        $query->bindValue("my_id", $id);
        $query->execute();
        $workout = $query->fetch(PDO::FETCH_ASSOC);

        $query = $this->pdo->prepare("
        UPDATE tanks 
        SET title=:title, image=:image, description=:description, info=:info, type=:type
        WHERE id = :id
        ");
        $query->bindValue("id", $id);
        $query->bindValue("title", $data['title'] ?? $workout['title']);
        $query->bindValue("image", $data['image'] ?? $workout['image']);
        $query->bindValue("description", $data['description'] ?? $workout['description']);
        $query->bindValue("info", $data['info'] ?? $workout['info']);
        $query->bindValue("type", $data['type'] ?? $workout['type']);
        $query->execute();

        return $data;
    }

    public function remove($id) {
        $query = $this->pdo->prepare("DELETE FROM tanks WHERE id = :my_id");
        $query->bindValue("my_id", $id);
        $query->execute();
         return [
            "delete" => True
        ];
    }
}
