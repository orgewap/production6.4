<?php
require_once "BaseTanksTwigController.php";

class MainController extends BaseTanksTwigController {
    public $template = "main.twig";
    public $title = "Главная";

    public function getContext(): array
    {
        $context = parent::getContext();

        $message = $_GET['message'] ?? null;
        $type = $_GET['type'] ?? null;

        if ($message) {
            $query = $this->pdo->prepare("SELECT * FROM tanks WHERE title LIKE :msg OR description LIKE :msg");
            $query->bindValue("msg", '%' . $message . '%');
            $query->execute();
            $context['message'] = $message;
        }
        elseif ($type) {
            $query = $this->pdo->prepare("SELECT * FROM tanks WHERE type = :type");
            $query->bindValue("type", $type);
            $query->execute();
        }
        else {
            $query = $this->pdo->query("SELECT * FROM tanks");
        }

        $context['world_of_tanks'] = $query->fetchAll();
        return $context;
    }
}
