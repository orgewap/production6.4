<?php
require_once __DIR__ . '/../framework/TwigBaseController.php';


class BaseTanksTwigController extends TwigBaseController {
    public function getContext(): array
    {
        $context = parent::getContext(); 

        // Получаем типы танков из базы данных
        $query = $this->pdo->query("SELECT DISTINCT name FROM tanks_types ORDER BY 1");
        $types = $query->fetchAll();
        $context['types'] = $types;

        // История переходов пользователя
        if (!isset($_SESSION['history'])) {
            $_SESSION['history'] = [];
        }

        $current = $_SERVER['REQUEST_URI'];
        if (empty($_SESSION['history']) || $_SESSION['history'][0] !== $current) {
            array_unshift($_SESSION['history'], $current);
        }
        $_SESSION['history'] = array_slice($_SESSION['history'], 0, 10);

        $context["history"] = $_SESSION['history'];

        
        $context["session"] = $_SESSION;

        return $context;
    }
}
