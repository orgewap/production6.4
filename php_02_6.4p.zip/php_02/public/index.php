
<?php 
    require_once '../vendor/autoload.php';
    require_once '../framework/autoload.php';

    require_once "../controllers/MainController.php";

    require_once "../controllers/Controller404.php";
    require_once "../controllers/ObjectController.php";
    require_once "../controllers/SearchController.php";
    require_once "../controllers/TanksObjectCreateController.php";
    require_once "../controllers/TanksObjectTypesController.php";
    require_once "../controllers/TanksObjectDeleteController.php";
    require_once "../controllers/TanksObjectUpdateController.php";

    require_once "../controllers/TanksRestController.php";
    require_once "../middlewares/LoginRequiredMiddleware.php";
    require_once "../controllers/SetWelcomeController.php";
    require_once "../controllers/LoginController.php";
    require_once "../controllers/LogoutController.php";

    $url = $_SERVER['REQUEST_URI'];

    $matches = [];
    if(preg_match('#^/api/tanks(/\d+)?/?#', $url, $matches)) {
        $id = substr($matches[1] ?? "", 1);
        //print_r($matches);
        $controller = new TanksRestController;
        $controller->process($id);
        
    }



    $loader = new \Twig\Loader\FilesystemLoader('../views');
    $twig = new \Twig\Environment($loader, [
        "debug" => true // добавляем тут debug режим
    ]);


    $twig->addExtension(new \Twig\Extension\DebugExtension()); // и активируем расширение
    $twig->addFilter(new \Twig\TwigFilter('urldecode', 'urldecode'));
    $context = [];

    $pdo = new PDO("mysql:host=localhost;dbname=world_of_tanks;charset=utf8", "root", "");

    $router = new Router($twig, $pdo);
    $router->add("/", MainController::class);
     $router->add("/login", LoginController::class);
    $router->add("/logout", LogoutController::class);
    $router->add("/set-welcome/", SetWelcomeController::class);
    $router->add("/tanks/(?P<id>\d+)", ObjectController::class); 
    $router->add("/search", SearchController::class);
    $router->add("/create", TanksObjectCreateController::class)
        ->middleware(new LoginRequiredMiddleware());
    $router->add("/types", TanksObjectTypesController::class)
        ->middleware(new LoginRequiredMiddleware());
    $router->add("/tanks/(?P<id>\d+)/delete", TanksObjectDeleteController::class)
        ->middleware(new LoginRequiredMiddleware());
    $router->add("/tanks/(?P<id>\d+)/edit", TanksObjectUpdateController::class)
        ->middleware(new LoginRequiredMiddleware());

    $router->get_or_default(Controller404::class);
?>
